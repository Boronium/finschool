# -*- coding: utf-8 -*-
#newschool.py

import finschool.school
from finschool.school import Student,SpecialStudent
from finschool.school import *

def Test():
	'''
	This is an example of coding by using this package
	st1 = school.Student('Albert',' Einstein')
	print(st1)

	st2 = Student('Bill','Gates')
	print([st2])

	stp1 = SpecialStudent('T','E','P')

	teacher1 = Teacher('Ada')
	print(teacher1.fullname)
	'''
	st1 = school.Student('Albert',' Einstein')
	print(st1)

	st2 = Student('Bill','Gates')
	print([st2])

	stp1 = SpecialStudent('T','E','P')

	teacher1 = Teacher('Ada')
	print(teacher1.fullname)