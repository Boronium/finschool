# -*- coding: utf-8 -*-
from finschool.school import Student, Lambhorgini, SpecialStudent, Teacher
from finschool.newschool import Test